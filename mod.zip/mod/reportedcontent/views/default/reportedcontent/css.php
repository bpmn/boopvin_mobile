<?php
/**
 * Elgg reported content CSS
 *
 * Footer link CSS
 * 
 * @package ElggReportContent
 */

?>
/* Reported Content */
.elgg-icon-report-this {
	background: url(<?php echo elgg_get_site_url(); ?>mod/reportedcontent/graphics/icon_reportthis.gif) no-repeat left top;
}
