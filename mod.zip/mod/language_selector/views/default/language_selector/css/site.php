<?php
?>
.language_selector_top {
	color: white;
        margin-top: 4px;
        margin-bottom: auto 
}



.language_selector_top > a {
	color: white;
}


.language_selector {
	position: absolute;
	right: 0px;
	top: 42px;
	color: white;
}

.language_selector > a {
	color: white;
}