<?php

$french = array(
    'language_selector:admin:settings:min_completeness' => "Quel est le pourcentage minimum d'exhaustivité d'une langue pour qu'elle puisse apparaitre dans la language_selector (ex 30)",
    'language_selector:admin:settings:show_in_header' => "Afficher les langues disponibles dans l'en-tête",
    'language_selector:admin:settings:autodetect' => "Activer la détection automatique de la langue (pour les utilisateurs non connectés)",
    'language_selector:admin:settings:show_images' => "Afficher le drapeau du pays (si disponible)",
);

add_translation("fr", $french);