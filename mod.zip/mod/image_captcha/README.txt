= Features =

- Provides a visual captcha validation mechanisme
- Use Plugin settings to switch between icon sets