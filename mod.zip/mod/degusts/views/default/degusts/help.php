<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$couleurs_rouge = '/mod/winetheme/views/default/css/winetheme/images/couleurs_rouge.jpg';
$couleurs_rouge = elgg_normalize_url($couleurs_rouge);

$reflets_rouge = '/mod/winetheme/views/default/css/winetheme/images/reflets_rouge.png';
$reflets_rouge = elgg_normalize_url($reflets_rouge);

$tasting = '/mod/winetheme/views/default/css/winetheme/images/tasting.jpg';
$tasting = elgg_normalize_url($tasting);

$vin_rouge = '/mod/winetheme/views/default/css/winetheme/images/vin_rouge.jpg';
$vin_rouge = elgg_normalize_url($vin_rouge);

?>
<div class ="help_paragraph">

</br>
<h1>Aide a la degustation</h1>
<h3>l'aide à la dégustation sera très prochainement en ligne n'hésitez à revenir régulièrement sur cette page. De nombreuses informations seront disponibles dans les prochains jours pour vous aider à remplir les fiches</h2>
</br>

</div>

