<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// change username form
$french = array(
    'profile_manager:account:username:button' => "Cliquer pour changer votre nom d'utilisateur",
    'profile_manager:account:username:info' => "Changer votre nom. Une icone vous informera de la validité et de la disponibilté du nom choisi",
    // register pre check
    'profile_manager:register_pre_check:missing' => 'Le champs suivant doit être renseigné: %s',
);

add_translation("fr", $french);

