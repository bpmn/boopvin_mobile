<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$french = array(
    'profile' => 'Profil',
    'profile:notfound' => "Désolé, nous n'avons pas pu trouver le profil demandé.",
    'profile:pro' => 'Travaillez vous dans le milieu du vin ou de la restauration ?',
    'profile:yes' => 'oui',
    'profile:no' => 'non',
    'profile:job' => 'Profession',
    'profile:aboutme' => 'A mon sujet...',
    'profile:degust:count'=>"%s dégustations"
);

add_translation('fr', $french);

