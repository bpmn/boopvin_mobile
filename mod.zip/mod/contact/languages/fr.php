<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$french = array(
    'contact' => 'contactez nous', 
    'contact:thanks' => " Merci de nous avoir contacté",
    'contact:merci' => " Merci !",
    'contact:required' => 'champs obligatoires',
    'contact:antispam' => 'SVP répondez à la question anti-spam',
    'contact:question' => "Question Anti-Spam",
    'contact:message' => "Message:",
    'contact:email' => "Votre adresse mail*:",
    'contact:name' => "Votre Nom*:",
    'contact:validate:name' => "Veuillez renseigner votre nom",
    'contact:validate:email' => "Veuillez renseigner votre adresse mail",
    'contact:validate:bad_email' => "Veuillez renseigner une adresse mail valide",
    'contact:validate:email' => "Message trop long !(plus de 2KB!)",
    'contact:validate:antispam' => "Veuillez répndre à la question anti-spam",
    'contact:antispam:error' => 'mauvaise réponse à la question anti spam'
);

add_translation("fr", $french);