<?php
/*
 *
 * Elgg Mobilize
 *
 * @package mobilize
 * @author Per Jensen - Elggzone
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU General Public License v2
 * @copyright Copyright (c) 2013, Per Jensen
 *
 * @link http://www.perjensen-online.dk/
 *
 */
 
elgg_register_event_handler('init','system','mobilize_init'); 

function mobilize_init(){ 

	$action_path = dirname(__FILE__) . '/actions';

	elgg_register_action("mobilize/admin/settings", "$action_path/settings.php", 'admin');
	elgg_register_admin_menu_item('configure', 'mobilize', 'settings');		

	elgg_extend_view('css/admin', 'mobilize/admin');
	
	elgg_register_page_handler('about', 'mobilize_expages_page_handler');
	elgg_register_page_handler('terms', 'mobilize_expages_page_handler');
	elgg_register_page_handler('privacy', 'mobilize_expages_page_handler');

	elgg_register_css('elgg.mobilize', '/css/mobilize.css');
		
	detectmobile();	
	$mobile = detectmobile();
		
	if($mobile == true) {
	        //elgg_extend_view('css/elgg', 'css/search/search');
            

		elgg_set_viewtype('mobile');
		
		if (!elgg_is_active_plugin('custom_index')) {
			elgg_unregister_plugin_hook_handler('index','system','custom_index');
			elgg_register_plugin_hook_handler('index', 'system', 'index_handler');
		} 
		
		if (elgg_get_plugin_setting('use_friendspicker', 'mobilize') == 'yes'){			
			elgg_unregister_js('elgg.friendspicker');
		}
                
                elgg_unregister_page_handler('wine', 'wine_page_handler');
                elgg_register_page_handler('wine', 'wine_page_handler_mobile');

                elgg_unregister_page_handler('degust', 'degust_page_handler');
                elgg_register_page_handler('degust', 'degust_page_handler_mobile');
                
                elgg_unregister_page_handler('profile', 'profile_page_handler');
                elgg_register_page_handler('profile', 'profile_page_handler_mobile');

             
						
		elgg_unregister_js('elgg.tinymce');	
		elgg_extend_view('page/elements/head','mobilize/meta', 1);
		
		elgg_register_js('mobilize', 'mod/mobilize/vendors/js/mobilize.js', 'footer');
		elgg_load_js('mobilize');

		elgg_register_event_handler('pagesetup', 'system', 'mobilize_setup_handler', 1000);
                

	}
	elgg_register_viewtype_fallback('mobile'); 
}

function index_handler($hook, $type, $return, $params) {

	if ($return == true) {
		// another hook has already replaced the front page
		return $return;
	}
	if (!include_once(dirname(__FILE__) . "/index.php")) {
		return false;
	}
	// return true to signify that we have handled the front page
	return true;
	
}

function mobilize_expages_page_handler($page, $handler) {

	if ($handler == 'expages') {
		expages_url_forwarder($page[1]);
	}
	$type = strtolower($handler);

	$title = elgg_echo("expages:$type");
	$content = elgg_view_title($title);

	$object = elgg_get_entities(array(
		'type' => 'object',
		'subtype' => $type,
		'limit' => 1,
	));
	if ($object) {
		$content .= elgg_view('output/longtext', array('value' => $object[0]->description));
	} else {
		$content .= elgg_echo("expages:notset");
	}
	$body = elgg_view_layout('one_sidebar', array('content' => $content));
	echo elgg_view_page($title, $body);

	return true;
}

function detectmobile(){
	if(preg_match('/(alcatel|amoi|android|avantgo|blackberry|benq|cell|cricket|docomo|elaine|htc|iemobile|iphone|ipaq|ipod|j2me|java|midp|mini|mmp|mobi|motorola|nec-|nokia|palm|panasonic|philips|phone|sagem|sharp|sie-|smartphone|sony|symbian|t-mobile|telus|up\.browser|up\.link|vodafone|wap|webos|wireless|xda|xoom|zte)/i', $_SERVER['HTTP_USER_AGENT'])) {
		return true;
	} else {
		//return false;
		return true;
	}
}

function mobilize_setup_handler() {

	if (!elgg_in_context('admin')) {
		elgg_load_css('elgg.mobilize');
	}
		
	// remove more menu dropdown
	elgg_unregister_plugin_hook_handler('prepare', 'menu:site', 'elgg_site_menu_setup');
			
	//elgg_unextend_view('page/elements/header', 'search/header');
	elgg_unregister_menu_item('footer', 'report_this');
	
	// Extend footer with copyright
	//$year = date('Y');	
	//$href = "http://www.perjensen-online.dk";
	//elgg_register_menu_item('footer', array(
		//'name' => 'copyright_this',
		//'href' => $href,
		//'title' => elgg_echo('mobilize:tooltip'),
		//'text' => elgg_echo('mobilize:copyright') . $year . elgg_echo(' Elggzone'),
		//'priority' => 1,
		//'section' => 'alt',
	//));
	
	// Extend footer with elgg link
	//$href = "http://elgg.org";
	//elgg_register_menu_item('footer', array(
	//	'name' => 'elgg',
	//	'href' => $href,
	//	'text' => elgg_echo('mobilize:elgg'),
	//	'priority' => 2,
	//	'section' => 'alt',
	//));
        
        // Register a page handler, so we can have nice URLs
	
        elgg_register_plugin_hook_handler('output:before', 'layout', 'change_degust_add_menu');
        
        

	if (elgg_is_logged_in()) {		
		if (elgg_is_active_plugin('dashboard')) {
			elgg_unregister_menu_item('topbar', 'dashboard');		
			elgg_register_menu_item('site', array(
				'name' => 'dashboard',
				'href' => '/dashboard',
				'text' => elgg_echo('dashboard'),
			));
		}		
		$user = elgg_get_logged_in_user_entity();		
		elgg_register_menu_item('footer', array(
			'name' => 'logout',
			'href' => '/action/logout',
			'is_action' => TRUE,
			'text' => elgg_echo('logout'),
			'priority' => 100,
			'section' => 'alt',
		));
		elgg_register_menu_item('footer', array(
			'name' => 'usersettings',
			'href' => "/settings/user/$user->username",
			'text' => elgg_echo('settings'),
			'priority' => 101,
			'section' => 'alt',
		));
		elgg_unregister_menu_item('topbar', 'friends');
		elgg_register_menu_item('site', array(
			'name' => 'friends',
			'text' => elgg_echo('friends'),
			'href' => "/friends/$user->username",
		));
		if (elgg_is_active_plugin('profile')) {
			elgg_unregister_menu_item('topbar', 'profile');
			elgg_register_menu_item('site', array(
				'name' => 'profile',
				'text' => elgg_echo('profile'),
				'href' => "/profile/$user->username",
			));
		}
		if (elgg_is_active_plugin('messages')) {	
			elgg_unregister_menu_item('topbar', 'messages');			
			$num_messages = (int)messages_count_unread();
			if ($num_messages != 0) {
				$text .= "<span class=\"messages-new\">$num_messages</span>";
			}							
			elgg_register_menu_item('site', array(
				'name' => 'messages',
				'href' => 'messages/inbox/' . elgg_get_logged_in_user_entity()->username,
				'text' => elgg_echo('messages') . $text,
			));
		}
                
                
                
                
                
                
                
                
                
	}	
	if (elgg_is_admin_logged_in()) {		
		elgg_register_menu_item('footer', array(
			'name' => 'administration',
			'href' => 'admin',
			'text' => elgg_echo('admin'),
			'priority' => 102,
			'section' => 'alt',
		));
	}
}

/**
 * Add the rss link to the extras when if needed
 *
 * @return void
 * @access private
 */
function change_degust_add_menu() {
	if (elgg_unregister_menu_item('title', 'degust:add')){
            $wine_guid=elgg_get_page_owner_guid();     
            $url = elgg_normalize_url("degust/add/{$wine_guid}");
            $url = elgg_add_action_tokens_to_url($url);
            $text = 'degust:add';
                
            $link_class='elgg-button elgg-button-action degust-add';
                        
            elgg_register_menu_item('title', array(
				'name' => $text,
				'href' => $url,
				'text' => elgg_echo($text),
				'link_class' => $link_class,
                                //'title'=>$text.':title'
                                //'target' =>"_blank",
                                //'rel'=>'#overlay',
			));
        
         }
         
         
         
         
}