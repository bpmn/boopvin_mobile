<?php
/**
 * Elgg dashboard blurb
 *
 */
?>

<div class="elgg-head clearfix">
    <h2 class="elgg-heading-main mobile-dashboard">
    <?php
        $title = elgg_echo('dashboard'); 
        echo $title;
    ?>
    </h2>
</div>
