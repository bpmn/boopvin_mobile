<?php
/**
 * Topic is closed
 */
echo "<h3>" . elgg_echo("groups:topicisclosed") . "</h3>";
echo "<p>" . elgg_echo("groups:topiccloseddesc") . "</p>";