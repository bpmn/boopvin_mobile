<?php
/**
 * Deregister the ElggNotification class
 */

update_subtype('object', 'notification');
