notifier
========

 The plugin should be installed to directory mod/notifier

 Features
  * Displays notifications in list that is easy to access from any page
  * Notification remains highlighted until user views the content
  * Notification won't appear again if there is unread notification that is exactly the same
  * Automatically removes read notifications after one week
  * Notifications can be dismissed or deleted manually
  * Built-in support for mentions plugin (https://github.com/Elgg/mentions)
  * Built-in support for comment_tracker plugin (https://github.com/beck24/Comment-Tracker-1.8.x)
